<?php

__("from ", "chronosly");
__("From ", "chronosly");
__("Organized by ", "chronosly");
__("Buy tickets", "chronosly");
__("Buy ", "chronosly");
__("Open map", "chronosly");
__("View ", "chronosly");
