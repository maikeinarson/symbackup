<input type="checkbox" name="calendar[]" <?php if($checked) echo "checked" ?> value="<?php echo $post->ID ?>" /> <?php echo $post->post_title;?><br/>

