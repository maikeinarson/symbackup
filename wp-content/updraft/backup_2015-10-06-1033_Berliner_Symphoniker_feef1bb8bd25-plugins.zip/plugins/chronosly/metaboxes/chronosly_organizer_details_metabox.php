
<label><?php _e("Phone", "chronosly");?></label> <input id="evo_phone" type="text" name="evo_phone"  value="<?php echo (isset($vars['evo_phone'][0])?$vars['evo_phone'][0]:"");?>"  /><br/>
<label><?php _e("Mail", "chronosly");?></label> <input id="evo_mail" type="text" name="evo_mail"  value="<?php echo (isset($vars['evo_mail'][0])?$vars['evo_mail'][0]:"");?>"  /><br/>
<label><?php _e("Web", "chronosly");?></label> <input id="evo_web" type="text" name="evo_web"  value="<?php echo (isset($vars['evo_web'][0])?$vars['evo_web'][0]:"");?>"  /><br/>

