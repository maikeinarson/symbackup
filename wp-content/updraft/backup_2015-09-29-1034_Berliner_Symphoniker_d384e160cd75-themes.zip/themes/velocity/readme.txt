Theme Name: Velocity - Responsive Business WordPress Theme
Theme URI: http://themeforest.net/user/damojo?ref=damojo
Author: Damojo
Author URI: http://themeforest.net/user/damojo?ref=damojo
Version: 1.0
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Description: Velocity is a responsive multipurpose wordpress theme with loads of features and layout options.