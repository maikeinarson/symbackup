<?php
/* ------------------------------------------------------------------------ *
 * Field Definitions
 * ------------------------------------------------------------------------ */ 
require_once(velocity_FUNCTIONS.'/theme_options/theme_options.php');

/* ------------------------------------------------------------------------ *
 * Build Functions
 * ------------------------------------------------------------------------ */ 
require_once(velocity_FUNCTIONS.'/theme_options/theme_options_functions.php');

/* ------------------------------------------------------------------------ *
 * Fields
 * ------------------------------------------------------------------------ */	
require_once(velocity_FUNCTIONS.'/theme_options/theme_options_fields.php');
require_once(velocity_FUNCTIONS.'/theme_options/theme_style_generate.php');

?>